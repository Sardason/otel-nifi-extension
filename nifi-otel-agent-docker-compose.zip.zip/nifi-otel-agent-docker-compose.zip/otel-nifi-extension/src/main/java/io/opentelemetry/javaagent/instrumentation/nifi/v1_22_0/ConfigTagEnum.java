package io.opentelemetry.javaagent.instrumentation.nifi.v1_22_0;

public enum ConfigTagEnum {
    ExternalPropagation,
    UseLinks,
    ThreadPrefixesExternalPropagation,
    NoOTEL
}
